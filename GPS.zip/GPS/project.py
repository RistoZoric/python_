from tkinter import NW, Label, Tk,Canvas,Frame,BOTH,ALL,LEFT
from turtle import bgcolor


#image manage class
from PIL import Image, ImageTk
#import math
import math

#import time
import time

#create screen
screen_width=480
screen_height=480
screen_bg="white"
interval=80

sub_screen_width=screen_width/2-interval
sub_screen_height=screen_height/2-interval

window=Tk()
window.title("GPS CLOCK")

canvas=Canvas(window,width=screen_width,height=screen_height,bg=screen_bg)
canvas.pack(padx=5,pady=0)
#create center
def CenterCirl():
    canvas.create_oval(screen_width/2-interval/2+1,screen_height/2-interval/2+1,screen_width/2+interval/2-1,screen_height/2+interval/2-1,width=3,outline="black",fill="red")

def ClockFace():
    for i in range(60):
        if i%5==0:
            DrawIndicate(math.pi*i/30,20,10)
        else:
            DrawIndicate(math.pi*i/30,10,4)

    # canvas.create_line() 
def DrawIndicate(angle,length,width):
    indicate=screen_width/2
    start_x=screen_width/2-math.sin(angle)*indicate
    start_y=screen_height/2-math.cos(angle)*indicate
    mark_length=length
    end_x=start_x+mark_length*math.sin(angle)
    end_y=start_y+mark_length*math.cos(angle)
    canvas.create_line(start_x,start_y,end_x,end_y,fill="black",width=width)
    #draw clock
def DrawingTime(h,min,sec,canvas):
    #hour
    h_length=screen_width/2-60
    h_width=15
    h_start_x=screen_width/2
    h_start_y=screen_height/2
    h_end_x=h_start_x+h_length*math.sin(math.pi*h/6+math.pi*min/360)
    h_end_y=h_start_y-h_length*math.cos(math.pi*h/6+math.pi*min/360)
    canvas.create_line(h_start_x,h_start_y,h_end_x,h_end_y,fill="red",width=h_width)
    #minutes
    min_length=screen_width/2-30
    min_width=10
    min_start_x=screen_width/2
    min_start_y=screen_height/2
    min_end_x=min_start_x+min_length*math.sin(math.pi*min/30)
    min_end_y=min_start_y-min_length*math.cos(math.pi*min/30)
    canvas.create_line(min_start_x,min_start_y,min_end_x,min_end_y,fill="red",width=min_width)
    #second
    sec_length=screen_width/2-10
    sec_width=5
    sec_start_x=screen_width/2
    sec_start_y=screen_height/2
    sec_end_x=sec_start_x+sec_length*math.sin(math.pi*sec/30)
    sec_end_y=sec_start_y-sec_length*math.cos(math.pi*sec/30)
    canvas.create_line(sec_start_x,sec_start_y,sec_end_x,sec_end_y,fill="red",width=sec_width)
#drawing angle from GPS
def drawAngle(angle,canvas):
    angle_length=sub_screen_width/2-15
    angle_width=5
    angle_start_x=screen_width/2
    angle_start_y=(screen_height+sub_screen_height+interval)/2
    angle_end_x=angle_start_x+angle_length*math.sin(math.pi*angle/180)
    angle_end_y=angle_start_y-angle_length*math.cos(math.pi*angle/180)
    canvas.create_line(angle_start_x,angle_start_y,angle_end_x,angle_end_y,fill="blue",width=angle_width)
    angle_radius=10
    canvas.create_oval(angle_start_x-angle_radius,angle_start_y-angle_radius,angle_start_x+angle_radius,angle_start_y+angle_radius,fill="blue")

#draw alt
def drawAlt(alt,canvas):
    feet=0.3048
    convert_alt=alt/(feet*100)
    alt_length=sub_screen_width/2-15
    alt_width=5
    alt_start_x=(screen_width+sub_screen_width+interval)/2
    alt_start_y=screen_height/2
    alt_end_x=alt_start_x+alt_length*math.sin(math.pi*convert_alt/50)
    alt_end_y=alt_start_y-alt_length*math.cos(math.pi*convert_alt/50)
    canvas.create_line(alt_start_x,alt_start_y,alt_end_x,alt_end_y,fill="green",width=alt_width)
    alt_radius=10
    canvas.create_oval(alt_start_x-alt_radius,alt_start_y-alt_radius,alt_start_x+alt_radius,alt_start_y+alt_radius,fill="green")

#draw temp
def drawTemp(temp,canvas):
    temp_length=sub_screen_width/2-15
    temp_width=5
    temp_start_x=(screen_width-sub_screen_width-interval)/2
    temp_start_y=screen_height/2
    if temp<-10 or temp>30:
        temp_end_x=temp_start_x+temp_length*math.sin(math.pi*(temp-10)/46)
        temp_end_y=temp_start_y-temp_length*math.cos(math.pi*(temp-10)/46)
    else:
        temp_end_x=temp_start_x+temp_length*math.sin(math.pi*(temp-10)/40)
        temp_end_y=temp_start_y-temp_length*math.cos(math.pi*(temp-10)/40)
    canvas.create_line(temp_start_x,temp_start_y,temp_end_x,temp_end_y,fill="purple",width=temp_width)
    temp_radius=20
    canvas.create_oval(temp_start_x-temp_radius,temp_start_y-temp_radius,temp_start_x+temp_radius,temp_start_y+temp_radius,fill="purple")

def update():

    canvas.delete(ALL)
    
    #import json file 
    import json
    with open("./data/data.json") as f:
        data=json.load(f)
    dump=json.dumps(data)

    canvas.create_oval(0,0,screen_width,screen_height, outline="black",fill="grey",width=2)

    #tem creation
    tem_width=int(screen_width/2-interval)
    tem_img=ImageTk.PhotoImage(Image.open('./assets/temnew.png').resize((tem_width,tem_width)))
    canvas.create_image(screen_width/4-tem_width/2,screen_height/2-tem_width/2,anchor=NW,image=tem_img)
    
    #angle creation
    angle_width=int(screen_width/2-interval)
    alt_img=ImageTk.PhotoImage(Image.open('./assets/anglenew.png').resize((angle_width,angle_width)))
    canvas.create_image(screen_width/2-angle_width/2,screen_height/2+interval/2,anchor=NW,image=alt_img)

    #alt creation
    alt_width=int(screen_width/2-interval)
    angle_img=ImageTk.PhotoImage(Image.open('./assets/altnew.png').resize((alt_width,alt_width)))
    canvas.create_image(screen_width/2+interval/2,screen_height/2-alt_width/2,anchor=NW,image=angle_img)

    CenterCirl()
    ClockFace()

    #get gps alt
    alt=data["GPS_ALT"]/10

    drawAlt(alt,canvas)

    #get temperatire
    temp=data["TEMP1"]

    drawTemp(temp,canvas)
    
    #get angle 
    angle=data["GPS_Angle"]

    drawAngle(angle,canvas)

    #get gps time
    gps_time=data['GPS_TIME']
    hour=int(gps_time/10000)
    min=int((gps_time-hour*10000)/100)
    sec=gps_time%100

    DrawingTime(hour,min,sec,canvas)
    #baud speed setting
    window.after(500,update)
    window.mainloop()

def main():


    update()

if __name__=='__main__':
    main()